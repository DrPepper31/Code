/*
Ryan Pepper
October 28th 2023
CIT 245
Hanoi
*/

#pragma warning(disable: 4996)
#include<string>
#include<stdlib.h>
#include<time.h>
#include<iostream>
using namespace std;

void towersOfHanoi(int n, char sorc, char targ, char temp)
{
    if (n == 1) 
    {
        cout << "from " << sorc << " to " << targ << endl;
        return;
    }

    towersOfHanoi(n - 1, sorc, temp, targ);
    cout << "from " << sorc << " to " << targ << endl;
    towersOfHanoi(n - 1, temp, targ, sorc );
}

int main() 
{
    int numDisks;
    char sorc = '1', targ = '2', temp = '3';
    int continueFlag;
    
    do 
    {
        cout << "Enter the number of disks: ";
        cin >> numDisks;

        cout << "source " << sorc << " target " << targ << " temporary " << temp << endl;
        towersOfHanoi(numDisks,sorc,targ,temp);

        int totalMoves = (1 << numDisks) - 1;
        cout << numDisks << " to the 2 power = " << totalMoves << endl ;
        cout << "Number of moves " << totalMoves << endl;

        cout << "Continue (1=yes, 0=no): ";
        cin >> continueFlag;
    } while (continueFlag == 1);
    return 0;
}