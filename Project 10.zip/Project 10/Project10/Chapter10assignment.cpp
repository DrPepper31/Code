/*
Ryan Pepper
October 14th 2023
CIT 245
Chapter 10 assignment
*/

#pragma warning(disable: 4996)
#include<string>
#include<stdlib.h>
#include<time.h>
#include<iostream>


class wrapArrayDeep
{
private:
    char* pch;

public:
    wrapArrayDeep() 
    {
        pch = new char[5];
        for (int i = 0; i < 5; i++)
            pch[i] = static_cast<char>(97 + i);
    }

    wrapArrayDeep(const wrapArrayDeep& other) 
    {
        pch = new char[5];
        for (int i = 0; i < 5; i++)
            pch[i] = other.pch[i];
    }

    ~wrapArrayDeep()
    {
        std::cout << "Destructor of WrapArrayDeep called\n";
        delete[] pch;
    }

    void printArray()
    {
        for (int i = 0; i < 5; i++)
            std::cout << pch[i] << " ";
        std::cout << "\n";
    }
};

class WrapArrayShallow 
{
private:
    char* pch;

public:
    WrapArrayShallow()
    {
        pch = new char[5];
    }

    WrapArrayShallow(const WrapArrayShallow& other) 
    {
        pch = other.pch;
    }

    ~WrapArrayShallow()
    {
        std::cout << "Destructor of WrapArrayShallow called\n";
    }

    void printArray() 
    {
        for (int i = 0; i < 5; i++)
            std::cout << *(pch + i) << " ";
        std::cout << "\n";
    }
};

int main()
{
    //part1
    int i = 7;
    int* pi = &i;

    std::cout << "Pointer pi: " << pi << "\n";
    std::cout << "Address of pi: " << &pi << "\n";
    std::cout << "Dereferenced pi: " << *pi << "\n";

    int** ppi = &pi;  
    std::cout << "Pointer ppi: " << ppi << "\n";
    std::cout << "Address of ppi: " << &ppi << "\n";
    std::cout << "Dereferenced ppi: " << *ppi << "\n";
    std::cout << "Double dereferenced ppi: " << **ppi << "\n";
    
    //part 2
    wrapArrayDeep wad1;
    wrapArrayDeep* wad2 = new wrapArrayDeep(wad1);
    std::cout << "WrapArrayDeep wad1: ";
    wad1.printArray();
    std::cout << "WrapArrayDeep wad2: ";
    wad2->printArray();
    delete wad2;

    WrapArrayShallow was1;
    WrapArrayShallow* was2 = new WrapArrayShallow(was1);
    std::cout << "WrapArrayShallow was1: ";
    was1.printArray();
    std::cout << "WrapArrayShallow was2: ";
    was2->printArray();
    delete was2;

    return 0;
}

