/*
Ryan Pepper
September 23rd 2023
CIT 245
Player
*/

#pragma warning(disable: 4996)
#include<string>
#include<stdlib.h>
#include<time.h>
#include<iostream>

using namespace std;

class player 
{
 private:
	string name;
	string password;
	int exp;
	string inventory[4];
	int locationY;
	int locationX;

 public:

	 //mutator methods
	 void setName(const string& playerName)
	 {
		 name = playerName;
	 }

	 void setPassword(const string& playerPassword)
	 {
		 password = playerPassword;
	 }

	 void setExp(int ePoints)
	 {
		 exp = ePoints;
	 }

	 void setInventory(const string inv[4])
	 {
		 for (int i = 0; i < 4; ++i) 
		 {
			 inventory[i] = inv[i];
		 }
	 }

	 void setLocation(int y, int x)
	 {
		 locationY = y;
		 locationX = x;
	 }

	 //accessor methods
	 int getExperiencePoints() const 
	 {
		 return exp;
	 }

	 const string* getInventory() const 
	 {
		 return inventory;
	 }

	 int getLocationX() const
	 {
		 return locationX;
	 }

	 string getPassword() const 
	 {
		 return password;
	 }
	 int getLocationY() const
	 {
		 return locationY;
	 }

	 void display() const
	 {
		 cout << "Player information: \n" << "Name: " << name << "\n" << "Password: " << password << "\n" << "Experience points: " << exp << "\n" << "Inventory: ";
		 for (int i = 0; i < 4;i++) 
		 {
			 cout << inventory[i] << "";
		 }
		 cout << "\n" << "Location: (" << locationX << ", " << locationY << ")\n";
	 }
};

int main()
{
	player player1;
	player1.setName("Jimmy");
	player1.setPassword("1234MYPASS");
	player1.setExp(9000);
	string inventory[] = {"sword, ","shield, ","potion, ","gem"};
	player1.setInventory(inventory);
	player1.setLocation(50,22);
	player1.display();
	cout << "\n";

	player player2;
	player2.setName("John");
	player2.setPassword("password");
	player2.setExp(40);
	string inventory2[] = { "long sword, ","potion, ","rations, ","hammer" };
	player2.setInventory(inventory2);
	player2.setLocation(0, 72);
	player2.display();
	cout << "\n";

	player player3;
	player3.setName("Joey");
	player3.setPassword("joeypassword1243");
	player3.setExp(8000001);
	string inventory3[] = { "magic sword, ","totem, ","mana potion, ","enchanted shield" };
	player3.setInventory(inventory3);
	player3.setLocation(89003, 4802);
	player3.display();
	cout << "\n";
}